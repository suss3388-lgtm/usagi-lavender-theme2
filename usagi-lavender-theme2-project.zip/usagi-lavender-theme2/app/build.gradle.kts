plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.suss3388.usagilavender"
    compileSdk = 35
    buildToolsVersion = "35.0.0"
    defaultConfig {
        applicationId = "com.suss3388.usagilavender"
        minSdk = 28
        targetSdk = 35
        versionCode = providers.environmentVariable("THEME_VERSION_CODE").orElse("1").get().toInt()
        versionName = "1.0.0"
    }
    sourceSets.getByName("main").res.srcDirs("src/main/theme", "src/main/theme-adv")
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }
    // KakaoTalk resolves theme resources by name, including resources not used by this launcher.
    buildTypes {
        getByName("debug") { isMinifyEnabled = false }
        getByName("release") {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
    val releaseStore = providers.environmentVariable("RELEASE_STORE_FILE").orNull
    if (!releaseStore.isNullOrBlank()) {
        signingConfigs.create("privateRelease") {
            storeFile = file(releaseStore)
            storePassword = providers.environmentVariable("RELEASE_STORE_PASSWORD").get()
            keyAlias = providers.environmentVariable("RELEASE_KEY_ALIAS").get()
            keyPassword = providers.environmentVariable("RELEASE_KEY_PASSWORD").get()
            enableV1Signing = true
            enableV2Signing = true
        }
        buildTypes.getByName("release").signingConfig = signingConfigs.getByName("privateRelease")
    }
}

dependencies {
    implementation("androidx.annotation:annotation:1.9.1")
}
