# 제작 자료와 출처

- 카카오 공식 사용자 테마 가이드·샘플: https://kko.kakao.com/hmVfyDMjOl
- 실제 다운로드: https://t1.kakaocdn.net/kakaotalk_theme/kakaotalk_theme_user_guide.zip
- 확인일: 2026-11-17 (한국 시간)
- Android 소스: `Android_Sample_Theme_26.9.0/apeach-26.9.0-source.zip`
- 공식 ZIP SHA-256: `82c0cf80993072d855010a9e3a8eb03281f70da3af287e54526f59a05ab308df`

공식 샘플의 테마 리소스 이름, 선택자, 적용 Activity를 사용했습니다. 앱 식별자·라벨·그림·색상은 우사기 라벤더로 변경하고, Gradle 모듈 구성과 manifest를 AGP 8에 맞춰 정리했습니다.

사용자가 이전 채팅에서 만든 `usagi_lavender_stage2_assets.zip`의 아이콘·패턴·말풍선 장식·앱 아이콘, `usagi_lavender_rebuild_materials.zip`의 채팅 배경을 사용했습니다. 원본 그림은 생성형 재작화 없이 크기 조정·리소스 매핑에 사용합니다. 그림별 SHA-256은 `source-assets.sha256.json`에 기록합니다.

`Witch Shop_DAY.apk`나 과거 TEST APK의 코드·서명·원본 테마 이미지는 저장소에 포함하지 않았습니다. `legacy_resource_map.csv`는 과거 리소스 이름을 비교하기 위한 기록이며 현재 빌드의 입력이 아닙니다. 라이선스나 재배포 권한을 새로 부여하지 않습니다.
