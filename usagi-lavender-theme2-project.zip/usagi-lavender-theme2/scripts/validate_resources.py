#!/usr/bin/env python3
"""Catch missing theme API resources, stale sample branding and unresolved XML references."""
from pathlib import Path
import re
import struct
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT/'app/src/main'
resources = set()
xml_files = []
for base in ['res', 'theme', 'theme-adv']:
    for p in (MAIN/base).rglob('*'):
        if not p.is_file():
            continue
        kind = p.parent.name.split('-')[0]
        if kind == 'values':
            tree = ET.parse(p)
            for node in tree.getroot():
                if 'name' in node.attrib:
                    resources.add((node.tag, node.attrib['name']))
        else:
            resources.add((kind, p.name.split('.')[0]))
        if p.suffix == '.xml':
            ET.parse(p)
            xml_files.append(p)
for p in xml_files + [MAIN/'AndroidManifest.xml']:
    for kind, name in re.findall(r'(?<![\w+])@(drawable|mipmap|color|string|style|layout)/([a-zA-Z0-9_]+)',p.read_text()):
        assert (kind,name) in resources, f'{p}: missing @{kind}/{name}'

for name in ['theme_background_image','theme_chatroom_background_image',
             'theme_maintab_cell_image','theme_passcode_background_image','theme_profile_01_image']:
    assert ('drawable',name) in resources, f'missing KakaoTalk resource: {name}'
for tab in ['friends','chats','now','shopping','more']:
    for focused in ['', '_focused']:
        assert ('drawable',f'theme_maintab_ico_{tab}{focused}_image') in resources
patches = list((MAIN/'theme').rglob('*.9.png'))
assert len(patches) == 5, f'expected four bubbles and one tab background, got {len(patches)}'
for p in patches:
    data = p.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n', p
    width,height,depth,mode = struct.unpack('>IIBB',data[16:26])
    assert min(width,height)>4 and depth==8 and mode==6, f'{p}: expected RGBA source NinePatch'
    assert b'npTc' not in data, f'{p}: compiled NinePatch must not be used as source'
for p in (MAIN/'theme').glob('values*/strings.xml'):
    values={n.attrib.get('name'):n.text for n in ET.parse(p).getroot()}
    assert values.get('app_name') == '우사기 라벤더' and values.get('theme_title') == '우사기 라벤더',p
manifest = ET.parse(MAIN/'AndroidManifest.xml').getroot()
assert 'package' not in manifest.attrib, 'AGP 8 requires namespace in build.gradle.kts'
permissions=[p.attrib['{http://schemas.android.com/apk/res/android}name'] for p in manifest.findall('uses-permission')]
assert permissions == ['com.kakao.talk.v2.theme'], permissions
assert 'com.suss3388.usagilavender' in (ROOT/'app/build.gradle.kts').read_text()
print(f'Validated {len(resources)} resource names, {len(xml_files)} XML files and {len(patches)} source NinePatches.')
