#!/usr/bin/env python3
"""Map the supplied art to official KakaoTalk names and author source NinePatch borders.
Requires Pillow only when regenerating; the generated Android resources are committed.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import shutil

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'design/source'
MAIN = ROOT / 'app/src/main'
THEME = MAIN / 'theme'
DRAW = THEME / 'drawable-xxhdpi'
DRAW.mkdir(parents=True, exist_ok=True)

def copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)

def ninepatch(image, name, stretch_x, stretch_y, content_x, content_y):
    image = image.convert('RGBA')
    w, h = image.size
    patch = Image.new('RGBA', (w + 2, h + 2))
    patch.paste(image, (1, 1))
    pen = ImageDraw.Draw(patch)
    black = (0, 0, 0, 255)
    pen.line((stretch_x[0]+1, 0, stretch_x[1]+1, 0), fill=black)
    pen.line((0, stretch_y[0]+1, 0, stretch_y[1]+1), fill=black)
    pen.line((content_x[0]+1, h+1, content_x[1]+1, h+1), fill=black)
    pen.line((w+1, content_y[0]+1, w+1, content_y[1]+1), fill=black)
    patch.save(DRAW / (name + '.9.png'))

# Resource names and tab selectors follow the official Android 26.9.0 template.
for tab, icon in {'friends':'friends', 'chats':'chat', 'now':'shortform',
                  'shopping':'shopping', 'more':'more', 'call':'chat',
                  'local':'more', 'piccoma':'more'}.items():
    for state in ('', '_focused'):
        copy(SOURCE / f'icons/{icon}_192.png', DRAW / f'theme_maintab_ico_{tab}{state}_image.png')

copy(SOURCE/'friends_chat_pattern_1080x1920.png', DRAW/'theme_background_image.png')
# Remove the template shape with the same resource name so the supplied pattern wins at every density.
(MAIN/'theme-adv/drawable/theme_background_image.xml').unlink(missing_ok=True)
for name in ['theme_chatroom_background_image', 'theme_passcode_background_image', 'theme_splash_image']:
    copy(SOURCE/'chatroom_background.png', DRAW/(name+'.png'))
copy(SOURCE/'theme_icon_512.png', DRAW/'theme_profile_01_image.png')
for name in ['theme_find_add_friend_button_image', 'theme_find_add_friend_button_pressed_image']:
    copy(SOURCE/'icons/friends_192.png', DRAW/(name+'.png'))

for side, fill, decoration in [('you','#FFFDF5','incoming'), ('me','#FFECC1','outgoing')]:
    # The top and corners are fixed; only an empty central strip stretches.
    # Text padding starts beneath the art, so short and multiline text cannot cover the character.
    first = Image.new('RGBA', (384, 288))
    ImageDraw.Draw(first).rounded_rectangle((4,112,379,283), radius=36, fill=fill)
    art = Image.open(SOURCE/f'bubble/{decoration}_decoration_192.png').convert('RGBA')
    art = art.resize((144,144), Image.Resampling.LANCZOS)
    first.alpha_composite(art, (8 if side == 'you' else 232, 0))
    ninepatch(first, f'theme_chatroom_bubble_{side}_01_image', (184,199),(190,201),(36,347),(156,247))
    follow = Image.new('RGBA', (144,108))
    ImageDraw.Draw(follow).rounded_rectangle((2,2,141,105), radius=32, fill=fill)
    ninepatch(follow, f'theme_chatroom_bubble_{side}_02_image', (68,75),(50,57),(30,113),(24,83))

cell = Image.new('RGBA', (16,16), '#F4EEFA')
ninepatch(cell,'theme_maintab_cell_image',(7,8),(7,8),(0,15),(0,15))

# Plain passcode dots replace every sample character image.
xml = THEME/'drawable'
xml.mkdir(exist_ok=True)
for number in range(1,5):
    for checked in [False, True]:
        color = '#76598D' if checked else '#DDD0EC'
        suffix = '_checked' if checked else ''
        (xml/f'theme_passcode_{number:02}{suffix}_image.xml').write_text(f'''<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="oval">
    <size android:width="18dp" android:height="18dp" />
    <solid android:color="{color}" />
</shape>
''')
# PNG launcher avoids template adaptive icons with stale foreground/background references.
for p in (MAIN/'res/mipmap-anydpi-v26').glob('*.xml'):
    p.unlink()
for name in ['ic_launcher', 'ic_launcher_round']:
    copy(SOURCE/'theme_icon_512.png', MAIN/f'res/mipmap-xxxhdpi/{name}.png')
print('Generated Usagi resources from supplied source art.')
