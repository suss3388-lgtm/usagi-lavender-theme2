#!/usr/bin/env python3
"""Supplement apksigner verification with archive and APK Signing Block checks."""
import pathlib
import sys
import zipfile

path=pathlib.Path(sys.argv[1])
with zipfile.ZipFile(path) as apk:
    assert apk.testzip() is None, 'Corrupt APK archive'
    for name in ['AndroidManifest.xml', 'resources.arsc', 'classes.dex']:
        assert name in apk.namelist(), f'Missing {name}'
report=pathlib.Path(str(path)+'.signature.txt').read_text()
assert 'Verified using v2 scheme (APK Signature Scheme v2): true' in report, 'APK v2 signature not verified'
assert b'APK Sig Block 42' in path.read_bytes(), 'Missing APK Signing Block'
print(f'{path.name}: archive integrity and APK v2 signature verified.')
