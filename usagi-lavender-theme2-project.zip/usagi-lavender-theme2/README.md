# 우사기 라벤더 · Android 카카오톡 테마

기존 채팅에서 만든 우사기 원본 그림을 카카오 공식 **26.9.0 Android 샘플 소스**에 연결한 프로젝트입니다. Android 9 이상, 카카오톡 26.9.x를 대상으로 구성했습니다. 실제 기기에서 설치·적용한 결과는 아직 확인하지 않았습니다.

## APK 받기

1. 저장소의 **Actions → Build Android APK**를 엽니다.
2. 초록색으로 완료된 실행을 선택합니다. 처음 실행이 없다면 **Run workflow → Run workflow**를 누릅니다.
3. 실행 화면 하단 **Artifacts → usagi-lavender-apk-번호**를 다운로드합니다. GitHub 로그인이 필요합니다.
4. ZIP을 풀고 `usagi-lavender-debug.apk`를 Android 휴대폰에 설치합니다.
5. 설치된 **우사기 라벤더** 앱을 열어 **테마 적용하기**를 누릅니다.

빌드 결과에는 APK, SHA-256, APK 서명 검증 결과, 패키지 정보가 포함됩니다. Artifacts는 30일 동안 보관합니다. 기존 테스트 APK와 식별자가 다른 `com.suss3388.usagilavender` 패키지를 사용합니다.

## 적용한 디자인

| 항목 | 구성 |
| --- | --- |
| 친구·채팅 목록 | 기존 우사기 엉덩이 반복 패턴 |
| 채팅방·잠금 배경 | 기존 라벤더 배경 |
| 받은 첫 말풍선 | `#FFFDF5`, 캐릭터 왼쪽 위, 말풍선 외곽선 없음 |
| 보낸 첫 말풍선 | `#FFECC1`, 캐릭터 오른쪽 위, 말풍선 외곽선 없음 |
| 연속 말풍선 | 같은 색의 둥근 말풍선, 장식 생략 |
| 기본 버튼·글자 강조 | 진한 라벤더 `#76598D` |
| 친구·채팅·지금·쇼핑·더보기 | 기존 원본 아이콘, 선택 여부와 무관하게 그림 유지 |
| 런처 아이콘·앱 이름 | 기존 우사기 아이콘 / 우사기 라벤더 |

말풍선은 Android 소스 `.9.png` 형식입니다. 캐릭터가 늘어나지 않는 고정 영역과 텍스트 여백을 지정했습니다. 화면 크기와 카카오톡 버전에 따른 위치·탭 아이콘 표시·멀티라인 말풍선은 기기 확인이 필요합니다. 글로벌 탭(콜·로컬·픽코마)은 확보된 그림을 재사용했습니다.

## 빌드

Android Studio에서 이 폴더를 열거나 JDK 17과 Android SDK 35로 실행합니다.

```sh
python3 scripts/validate_resources.py
./gradlew :app:assembleDebug :app:lintDebug
```

`main` 코드 변경, Pull Request, 수동 실행으로 Actions가 동작합니다. 리소스 검증 → APK 빌드·lint → apksigner v2 서명 검증 → 앱 식별자·표시 이름 확인 → APK 업로드 순서입니다. 문서만 수정한 push는 빌드하지 않습니다. Gradle 8.10.2 / Android Gradle Plugin 8.7.2 / Kotlin 1.9.25 / Build Tools 35.0.0을 사용합니다.

## 서명과 업데이트

기본 산출물은 설치 가능한 **개발용 서명 APK**입니다. 기본 브랜치의 개발용 키는 GitHub Actions 캐시를 통해 재사용합니다. 캐시는 영구 저장소가 아니므로 삭제·만료되면 서명이 바뀔 수 있으며, 이 경우 이전 테마 앱을 삭제한 뒤 새 APK를 설치해야 합니다. PR 빌드는 별도 개발용 키를 사용합니다.

계속 같은 서명으로 배포하려면 개인 키를 보관하고 **Settings → Secrets and variables → Actions**에 다음 저장소 Secrets를 등록합니다. 키 파일을 공개 저장소에 커밋하지 않습니다.

| Secret | 값 |
| --- | --- |
| `ANDROID_KEYSTORE_BASE64` | 개인 keystore 파일의 Base64 값 |
| `ANDROID_KEYSTORE_PASSWORD` | keystore 비밀번호 |
| `ANDROID_KEY_ALIAS` | 키 별칭 |
| `ANDROID_KEY_PASSWORD` | 키 비밀번호 |

네 항목을 등록하면 main 빌드에서 `usagi-lavender-release.apk`도 생성·검증합니다. 미등록 상태에서도 개발용 APK는 빌드됩니다. 개발용과 배포용 키는 서로 달라 처음 전환 시 테마 앱 재설치가 필요합니다.

## 소스 구성

- `app/src/main/theme/`: 카카오톡이 읽는 색·이름·그림·NinePatch
- `app/src/main/theme-adv/`: 공식 리소스 선택자
- `app/src/main/java/`: 테마 적용 화면
- `design/source/`: 이전 제작 자료의 원본 그림
- `scripts/generate_resources.py`: 원본 그림의 리소스 매핑 및 NinePatch 생성
- `.github/workflows/build-apk.yml`: 자동 빌드 및 검증
- `docs/SOURCES.md`: 원본과 공식 샘플의 출처

이미지를 다시 매핑하려면 Pillow를 설치하고 `python3 scripts/generate_resources.py`를 실행합니다. 일반 빌드에는 Pillow가 필요하지 않습니다. 생성된 리소스를 함께 커밋하므로 Actions는 이미지 재생성 없이 빌드합니다.
